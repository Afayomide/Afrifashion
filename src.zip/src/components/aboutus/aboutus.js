export default function AboutUs () {
    return(
        <div>

        </div>
    )
}